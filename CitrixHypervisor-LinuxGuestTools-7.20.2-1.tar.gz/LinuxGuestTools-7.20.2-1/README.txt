Citrix Hypervisor Tools For Linux Guest
=======================================

This "tar package" / "CD file" contains the Citrix Hypervisor Tools
for Linux Guest. You will need to install them to get the best
performance from your virtual machine.

Linux users need to install the guest tools from the root directory
"in the tar package" / "from the CD".

You can install the required packages by running install.sh like so:

$ <somedir>/install.sh

where <somedir> is the root directory of the unzipped package or the
iso mount point.

